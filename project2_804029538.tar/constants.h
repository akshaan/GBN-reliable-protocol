#define MAX_PACKET_SIZ 1024
 
#define GETADDR_ERR 1
#define SOCK_ERR 2
#define LIST_ERR 3
#define BIND_ERR 4
#define ACC_ERR 5
